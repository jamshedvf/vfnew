================
jQuery GreyScale
================
A jQuery plugin for greyscaleing images on the fly and then colouring them on hover.

See example.html for a usage.

Tested in IE6-9, Safari, Chrome and FireFox.

Please send bug reports and feature requests to andrew@pryde-design.co.uk or log them in the issue queue on github (https://github.com/Prydie/jQuery-GreyScale-Plugin/issues).

Pull requests are welcome.

Rewrite
=======
The rewrite branch is a full rewrite of the plugin which aims to solve isues with the changes to jQuery since release as well as exposing the internals of the plugin to enable use with your own event handlers.
